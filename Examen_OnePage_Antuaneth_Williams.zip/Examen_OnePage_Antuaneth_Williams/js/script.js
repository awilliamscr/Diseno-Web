document.addEventListener("DOMContentLoaded", function () {
  const scrollTopButton = document.getElementById("scroll-top");

  window.addEventListener("scroll", function () {
      if (window.scrollY > 300) {
          scrollTopButton.style.display = "block";
      } else {
          scrollTopButton.style.display = "none";
      }
  });

  scrollTopButton.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
  });

  document.getElementById("subscription-form").addEventListener("submit", function (event) {
      event.preventDefault();
      alert("Gracias por suscribirte!");
  });
});

window.onscroll = function() {
  let scrollTopBtn = document.getElementById("scrollTopBtn");
  if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
      scrollTopBtn.style.display = "block";
  } else {
      scrollTopBtn.style.display = "none";
  }
};

document.getElementById("scrollTopBtn").onclick = function() {
  window.scrollTo({
      top: 0,
      behavior: "smooth"
  });
};
