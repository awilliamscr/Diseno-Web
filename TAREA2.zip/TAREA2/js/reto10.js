function redirectToLogin() {
    window.location.href = 'index.html';
}

function redirectToCantonesPDF() {
    window.location.href = 'pdf/cantones.pdf';
}

function redirectToHerediaPDF() {
    window.location.href = 'pdf/heredia.pdf';
}