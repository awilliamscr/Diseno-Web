function redirectToLogin() {
    window.location.href = 'index.html';
}