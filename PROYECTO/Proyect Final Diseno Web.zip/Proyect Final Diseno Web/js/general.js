 window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled'); // Se agrega la clase 'scrolled'
    } else {
      navbar.classList.remove('scrolled'); // Se elimina la clase 'scrolled'
    }
  });


 // Evitar que el formulario se envíe y mostrar el modal
document.getElementById("formReserva").addEventListener("submit", function(event) {
event.preventDefault();  // Evita que el formulario se envíe realmente
var modal = new bootstrap.Modal(document.getElementById('modalReserva')); // Inicializa el modal
modal.show();  // Muestra el modal
});


document.getElementById("formContacto").addEventListener("submit", function(event) {
event.preventDefault();  // Evita el envío real
alert("Mensaje enviado correctamente.");
});

document.addEventListener('DOMContentLoaded', function() {
  const galeriaItems = document.querySelectorAll('.galeria-item');

  galeriaItems.forEach((item, index) => {
    setTimeout(() => {
      item.classList.add('visible');
    }, index * 300); // Delay de 300ms entre cada imagen
  });
});